package com.jobportal.entity;

public enum UserRole {
    JOB_SEEKER,
    EMPLOYER
}
