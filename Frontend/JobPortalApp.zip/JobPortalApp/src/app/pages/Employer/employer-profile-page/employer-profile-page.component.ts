import { Component } from '@angular/core';

@Component({
  selector: 'app-employer-profile-page',
  imports: [],
  templateUrl: './employer-profile-page.component.html',
  styleUrl: './employer-profile-page.component.css'
})
export class EmployerProfilePageComponent {

}
