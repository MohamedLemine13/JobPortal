import { Component } from '@angular/core';

@Component({
  selector: 'app-job-posting-form',
  imports: [],
  templateUrl: './job-posting-form.component.html',
  styleUrl: './job-posting-form.component.css'
})
export class JobPostingFormComponent {

}
