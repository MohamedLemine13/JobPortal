import { Component } from '@angular/core';

@Component({
  selector: 'app-application-viewer',
  imports: [],
  templateUrl: './application-viewer.component.html',
  styleUrl: './application-viewer.component.css'
})
export class ApplicationViewerComponent {

}
